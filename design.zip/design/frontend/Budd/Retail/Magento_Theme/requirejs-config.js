var config = {
    paths: {
            'bootstrap':'Budd_Retail/js/bootstrap.bundle'
            // 'rockwell':'https://fonts.googleapis.com/css2?family=Encode+Sans+Semi+Condensed:wght@500&family=Roboto:wght@300&display=swap'
    } ,
    shim: {
        'bootstrap': {
            'deps': ['jquery']
        }
    }
};